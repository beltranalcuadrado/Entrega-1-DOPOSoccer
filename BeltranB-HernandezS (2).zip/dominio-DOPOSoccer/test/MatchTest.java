package test;

import domain.Match;
import domain.POOBSoccerException;
import org.junit.Test;
import static org.junit.Assert.*;

public class MatchTest {

    @Test
    public void deberiaLanzarExcepcionConTipoInvalido(){
        try{
            new Match("OTRO", 3);
            fail("Debió lanzar excepción");
        }
        catch (POOBSoccerException e){
            assertEquals(POOBSoccerException.INVALID_MATCH_TYPE, e.getMessage());
        }
    }

    @Test
    public void deberiaLanzarExcepcionConLimiteInvalido(){
        try{
            new Match(Match.GOALS, 0);
            fail("Debió lanzar excepción");
        }
        catch (POOBSoccerException e){
            assertEquals(POOBSoccerException.INVALID_LIMIT, e.getMessage());
        }
    }

    @Test
    public void deberiaEmpezarConMarcadorEnCero() throws POOBSoccerException{
        Match partido = new Match(Match.GOALS, 3);
        assertEquals(0, partido.getGoals1());
        assertEquals(0, partido.getGoals2());
        assertFalse(partido.isFinished());
    }

    @Test
    public void noDeberiaAvanzarEnPausa() throws POOBSoccerException{
        Match partido = new Match(Match.GOALS, 3);
        partido.pause();
        int yInicial = partido.getBall().getY();
        for (int i = 1; i <= 30; i++){
            partido.update();
        }
        assertEquals(yInicial, partido.getBall().getY());
    }

    @Test
    public void deberiaMostrarTiempoRestanteEnModoTiempo() throws POOBSoccerException{
        Match partido = new Match(Match.TIME, 2);
        assertEquals(120, partido.getRemainingTime());
        for (int i = 1; i <= 60; i++){
            partido.update();
        }
        assertEquals(119, partido.getRemainingTime());
    }

    @Test
    public void noDeberiaTenerTiempoEnModoGoles() throws POOBSoccerException{
        Match partido = new Match(Match.GOALS, 3);
        assertEquals(-1, partido.getRemainingTime());
    }

    @Test
    public void noDeberiaHaberGanadorSiTerminaEmpatado() throws POOBSoccerException{
        Match partido = new Match(Match.GOALS, 3);
        partido.end();
        assertTrue(partido.isFinished());
        assertNull(partido.getWinner());
    }
}