package test;

import domain.Player;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Before;

public class PlayerTest{
    private Player jugador;
    @Before
    public void setUp(){
        jugador = new Player(100);
    }
    @Test
    public void deberiaSaltarYVolverAlSuelo(){
        jugador.jump();
        jugador.update();
        assertTrue(jugador.getY() < 450); //Está en el aire

        for (int i = 1; i <= 100; i++){
            jugador.update();
        }
        assertEquals(450, jugador.getY());
        assertTrue(jugador.isOnGround());
    }  

    @Test
    public void noDeberiaSaltarEnElAire(){
        jugador.jump();
        for (int i = 1; i <= 25; i++){
            jugador.update();
        }
        int y = jugador.getY();
        jugador.jump(); //Este jump no deberia funcionar, aun esta en el aire
        jugador.update();
        assertTrue(y < jugador.getY());
}
}