package test;

import domain.Ball;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Before;

public class BallTest {
    private Ball balon;
    @Before
    public void setUp(){
        balon = new Ball();
    }

    @Test
    public void deberiaEmpezarEnElCentro(){
        assertEquals(500, balon.getX());
        assertEquals(100, balon.getY());
    }

    @Test
    public void deberiaRebotarEnElSuelo(){
        boolean reboto = false;
        for (int i = 1; i <= 30; i++){
            balon.update();
            if (balon.getVelocityY() < 0){
                reboto = true;
            }
        }
        assertTrue(reboto);
    }

    @Test
    public void deberiaRebotarEnLaPared(){
        balon.push(-20,0);

        for (int i = 1; i <= 40; i++){
            balon.update();
        }
        assertTrue(balon.getX() > 0);
    }

    @Test
    public void deberiaVolverAlCentroConReset(){
        balon.push(30, 10);
        for (int i = 0; i <= 10; i++){
            balon.update();
        }
        balon.reset();
        assertEquals(500, balon.getX());
        assertEquals(100, balon.getY());
    }

    @Test
    public void deberiaDetenerseEventualmente(){
        balon.push(10, 0);
        for (int i = 1; i <= 500; i++){
            balon.update();
        }
        assertEquals(0, balon.getVelocityX());
        assertEquals(0, balon.getVelocityY());
    }
}
