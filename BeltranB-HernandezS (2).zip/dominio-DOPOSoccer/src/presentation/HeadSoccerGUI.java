package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import domain.*; 
import java.awt.image.BufferedImage;
import presentation.*;

public class HeadSoccerGUI extends JFrame {


    private Match match;
    private boolean moviendoIzquierdaJ1 = false;
    private boolean moviendoDerechaJ1 = false;
    private boolean moviendoIzquierdaJ2 = false;
    private boolean moviendoDerechaJ2 = false;


    private Timer timer;
    private PanelTablero tableroGUI;

    public HeadSoccerGUI() {
        ResourceManager.inicializar();
        match = new Match();
        
        prepareView();
        prepareController();
        iniciarJuego();
    }

    private void prepareView() {
        setSize(800, 600); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        tableroGUI = new PanelTablero();
        tableroGUI.setBackground(Color.DARK_GRAY);
        add(tableroGUI, BorderLayout.CENTER);
    }

    private void prepareController() {
            addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    moviendoIzquierdaJ1 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    moviendoDerechaJ1 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    match.getPlayer1().jump();
                }
                if (e.getKeyCode() == KeyEvent.VK_A) {
                    moviendoIzquierdaJ2 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_D) {
                    moviendoDerechaJ2 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_W) {
                    match.getPlayer2().jump();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_A) {
                    moviendoIzquierdaJ1 = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_D) {
                    moviendoDerechaJ2 = false;
                }

                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    moviendoIzquierdaJ2 = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    moviendoDerechaJ2 = false;
                }
            }
        });
        setFocusable(true);
        requestFocusInWindow();
            }


    private void iniciarJuego() {
        ResourceManager.inicializar();
        timer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (moviendoIzquierdaJ1) {
                    match.getPlayer1().move(-5); 
                }
                else if (moviendoDerechaJ1) {
                    match.getPlayer1().move(5);
                }
                else {
                    match.getPlayer1().stop(); 
                }

                if (moviendoIzquierdaJ2) {
                    match.getPlayer2().move(-5); 
                }
                else if (moviendoDerechaJ2) {
                    match.getPlayer2().move(5);
                }
                else {
                    match.getPlayer2().stop(); 
                }
                match.update();
                tableroGUI.repaint();
            }
        });
        timer.start();
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g; 
        
        BufferedImage imgBalon = ResourceManager.getSprite("balon");
        
        int xBalon = (int) partida.getBalon().getX();
        int yBalon = (int) partida.getBalon().getY();
        
        g2d.drawImage(imgBalon, xBalon, yBalon, null);
        
        g2d.setFont(ResourceManager.fuenteArcade);
        g2d.drawString("SCORE: " + partida.getScore(), 50, 50);
    }
}

class PanelTablero extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g; 

            BufferedImage imgBalon = ResourceManager.getSprite("ball");
            BufferedImage imgJ1 = ResourceManager.getSprite("player1");
            BufferedImage imgJ2 = ResourceManager.getSprite("player2");

            if (imgBalon != null && imgJ1 != null && imgJ2 != null && match != null) {
                
                int xBalon = (int) match.getBall().getX();
                int yBalon = (int) match.getBall().getY();
                g2d.drawImage(imgBalon, xBalon, yBalon, null);
                
                int xJ1 = (int) match.getPlayer1().getX();
                int yJ1 = (int) match.getPlayer1().getY();
                g2d.drawImage(imgJ1, xJ1, yJ1, null);
                
                int xJ2 = (int) match.getPlayer2().getX();
                int yJ2 = (int) match.getPlayer2().getY();
                g2d.drawImage(imgJ2, xJ2, yJ2, null);
            }

            if (ResourceManager.fuenteArcade != null) {
                g2d.setFont(ResourceManager.fuenteArcade);
                g2d.setColor(Color.WHITE);
            }
        
        }
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new HeadSoccerGUI().setVisible(true);
            }
        });
    }
    }