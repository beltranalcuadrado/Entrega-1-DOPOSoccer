package presentation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Font;
import java.io.File;
import java.util.HashMap;

public class ResourceManager {
    private static HashMap<String, BufferedImage> sprites = new HashMap<>();
    public static Font fuenteArcade;

    public static void inicializar() {
        try {
            sprites.put("p1_piernas", ImageIO.read(new File("sprites/p1_piernas.png")));
			sprites.put("p1_cuerpo", ImageIO.read(new File("sprites/p1_cuerpo.png")));
			sprites.put("p1_cabeza", ImageIO.read(new File("sprites/p1_cabeza.png")));
			sprites.put("p1_sombrero", ImageIO.read(new File("sprites/p1_sombrero.png")));
            sprites.put("ball", ImageIO.read(new File("sprites/balon.png")));
			sprites.put("p2_piernas", ImageIO.read(new File("sprites/p2_piernas.png")));
			sprites.put("p2_cuerpo", ImageIO.read(new File("sprites/p2_cuerpo.png")));
			sprites.put("p2_cabeza", ImageIO.read(new File("sprites/p2_cabeza.png")));
			sprites.put("p2_sombrero", ImageIO.read(new File("sprites/p2_sombrero.png")));
            
            fuenteArcade = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/arcade.ttf")).deriveFont(24f);
        } catch (Exception e) {
            System.err.println("Error cargando recursos: " + e.getMessage());
        }
    }

    public static BufferedImage getSprite(String nombre) {
        return sprites.get(nombre);
    }
}


