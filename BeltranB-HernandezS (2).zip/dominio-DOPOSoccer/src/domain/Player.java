package domain;

public class Player{
    private static final int GRAVITY = 1;
    private static final int SPEED = 10;
    private static final int JUMP_FORCE = 18;
    private static final int GROUND = 450;
    private static final int PITCH_WIDTH = 1000;
    public static final int SIZE = 60;

    private int x;
    private int y;
    private int velocityX;
    private int velocityY;
    private boolean onGround;

    public Player(int x){
        resetPlayer(x);
    }

    public void moveLeft(){
        velocityX = -SPEED;
    }

    public void moveRight(){
        velocityX = SPEED;
    }

    public void stop(){
        velocityX = 0;
    }

    public void jump(){
        if (onGround){
            velocityY = -JUMP_FORCE; //Negativo hacia arriba, positivo hacia abajo
            onGround = false;
        }
    }

    public void update(){
        velocityY += GRAVITY;
        x += velocityX;
        y += velocityY;

        if (y >= GROUND){ //Revisar si el jugador esta en el suelo
            y = GROUND;
            onGround = true;
            velocityY = 0;
        }
        else{
            onGround = false;
        }

        //Revisar que el jugador no se salga de las paredes
        if (x < 0){
            x = 0;
        }
        if (x > PITCH_WIDTH){
            x = PITCH_WIDTH;
        }

    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public boolean isOnGround(){
        return onGround;
    }

    public int getVelocityX(){
        return velocityX;
    }

    public void resetPlayer(int startX){
        x = startX;
        y = GROUND;
        velocityX = 0;
        velocityY = 0;
        onGround = true;
    }
}