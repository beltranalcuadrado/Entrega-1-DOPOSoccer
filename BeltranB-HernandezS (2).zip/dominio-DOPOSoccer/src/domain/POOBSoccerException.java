package domain;

public class POOBSoccerException extends Exception{
    public static final String INVALID_MATCH_TYPE = "El tipo de partido no es válido";
    public static final String INVALID_LIMIT = "El límite debe ser mayor que 0";

    public POOBSoccerException(String message){
        super(message);
    }
}
