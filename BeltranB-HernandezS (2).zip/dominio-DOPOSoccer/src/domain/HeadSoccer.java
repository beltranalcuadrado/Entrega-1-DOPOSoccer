package domain;

public class HeadSoccer {
    private Match match;

    public HeadSoccer(String matchType, int limit) throws POOBSoccerException{
        match = new Match(matchType, limit);
    }

    private Player getPlayer(int player){
        if (player == 1){
            return match.getPlayer1();
        }
        else{
            return match.getPlayer2();
        }
    }
    
    //Controles
    public void moveLeft(int player){
        getPlayer(player).moveLeft();
    }

    public void moveRight(int player){
        getPlayer(player).moveRight();
    }

    public void stop    (int player){
        getPlayer(player).stop();
    }

    public void jump(int player){
        getPlayer(player).jump();
    }

    public void kick(int player){
        match.kick(player);
    }

    //Ciclo
    public void update(){
        match.update();
    }

    public void pause(){
        match.pause();
    }

    public void resume(){
        match.resume();
    }

    public boolean isPaused(){
        return match.isPaused();
    }
    
    public void end(){
        match.end();
    }

    //Para dibujar
    public int getPlayerX(int player){
        return  getPlayer(player).getX();
    }

    public int getPlayerY(int player){
        return getPlayer(player).getY();
    }

    public int getBallX(){
        return match.getBall().getX();
    }

    public int getBallY(){
        return match.getBall().getY();
    }

    public int getPlayerSize(){
        return Player.SIZE;
    }

    public int getBallSize(){
        return Ball.SIZE;
    }

    public int getPitchWidth(){
        return 1000; //anchjo de la cancha
    }

    public int getPitchHeight(){
        return 500; //altura de la cancha
    }

    //Estado
    public int getGoals(int player){
        if (player == 1){
            return match.getGoals1();
        }
        else{
            return match.getGoals2();
        }
    }

    public int getRemainingTime(){
        return match.getRemainingTime();
    }

    public boolean isFinished(){
        return match.isFinished();
    }

    public int getWinner(){
        Player win = match.getWinner();
        if (win == match.getPlayer1()){
            return 1;
        }
        else if (win == match.getPlayer2()){
            return 2;
        }
        else{
            return 0;
        }
        
    }

    
}
