package domain;

public class Ball{
    private static final int GRAVITY = 1;
    private static final int GROUND = 450;
    private static final int PITCH_WIDTH = 1000;
    private static final int START_X = 500;
    private static final int START_Y = 100;
    private static final double REBOUND = 0.7;
    private static final double FRICTION = 0.95;
    public static final int SIZE = 30;

    private int x;
    private int y;
    private int velocityX;
    private int velocityY;

    public Ball(){
        reset();
    }

    public void reset(){
        x = START_X;
        y = START_Y;
        velocityX = 0;
        velocityY = 0;
    }

    public void push(int velX, int velY){
        velocityX = velX;
        velocityY = velY;
    }

    public void update(){
        velocityY += GRAVITY;
        x += velocityX;
        y += velocityY;

        if (y >= GROUND){
            y = GROUND;

            if (velocityY * REBOUND <= 2){ //Al multiplicar por 0.7 con el paso del tiempo nunca va a detenerse el rebote
                velocityY = 0;
            }
            else{ //Si el rebote aun es alto entonces el balon vuelve a subir
                velocityY = (int) -(velocityY * REBOUND);
            }
        }
        // Paredes
        if (x < 0){
            x = 0;
            velocityX = -velocityX;
        }

        if (x > PITCH_WIDTH){
            x = PITCH_WIDTH;
            velocityX = -velocityX;
        }
        
        //Techo
        if (y < 0){
            y = 0;
            velocityY = -velocityY;
        }

        //Friccion
        if (y == GROUND){
            velocityX = (int) (velocityX * FRICTION);
            if (Math.abs(velocityX * FRICTION) <= 2){
                velocityX = 0;
            }
        }
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int getVelocityX(){
        return velocityX;
    }

    public int getVelocityY(){
        return velocityY;
    }
}

